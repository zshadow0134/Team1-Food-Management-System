package me.zhulin.shopapi.enums;


public interface CodeEnum {
    Integer getCode();

}
