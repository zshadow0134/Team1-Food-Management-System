-- the order of values is related to the name of field.
-- Updating is necessary, if the name is changed



INSERT INTO "public"."order_main" VALUES (2, 'New bus Station, Kanpur, Uttar Pradesh', 'customer2@email.com', 'customer2', '9876543210', '2022-06-20 12:52:20.439', 1110.00, 1, '2022-06-20 12:52:20.439');
INSERT INTO "public"."order_main" VALUES (1, 'Fazalganj, Kanpur, UP', 'customer1@email.com', 'customer1', '1234567890', '2022-06-20 13:01:06.943', 1300.00, 1, '2022-06-20 13:02:56.498');

-- ----------------------------
-- Table structure for product_category

-- ----------------------------
-- Records of product_category
-- ----------------------------
INSERT INTO "public"."product_category" VALUES (2147483641, 'Recommended', 0, '2018-03-09 23:03:26', '2018-03-10 00:15:27');
INSERT INTO "public"."product_category" VALUES (2147483642, 'Non-Vegan Items', 2, '2018-03-10 00:15:02', '2018-03-10 00:15:21');
INSERT INTO "public"."product_category" VALUES (2147483644, 'Beverages and Dessert', 3, '2018-03-10 01:01:09', '2018-03-10 01:01:09');
INSERT INTO "public"."product_category" VALUES (2147483645, 'Vegan Items', 1, '2018-03-10 00:26:05', '2018-03-10 00:26:05');


-- ----------------------------
-- Records of product_in_order
-- ----------------------------
INSERT INTO "public"."product_in_order" VALUES (2147483642, 0,1,'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,96,NULL, 2147483641);
INSERT INTO "public"."product_in_order" VALUES (2147483644, 0,1, 'Learn Spring', 'https://images-na.ssl-images-amazon.com/images/I/51gHy16h5TL._SX397_BO1,204,203,200_.jpg', 'B0002', 'Spring In Action', 20.00,195,NULL, 2147483643);
INSERT INTO "public"."product_in_order" VALUES (2147483646, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00,57,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483648, 3,1,'Awesome', 'https://starbuckssecretmenu.net/wp-content/uploads/2017/06/Starbucks-Violet-Drink.jpg', 'D0002', 'Starbucks Violet Drink', 2.00,200,NULL, 2147483647);
INSERT INTO "public"."product_in_order" VALUES (2147483640, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00,57,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483641, 2,1, 'Boys Clothes', 'https://d2ul0w83gls0j4.cloudfront.net/taxonomy/300/0102/20171024151632.jpg', 'C0002', 'Shirts', 13.00,108,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483632, 1,1, 'Family s', 'http://cdn1.thecomeback.com/wp-content/uploads/2017/05/mcdonalds_food-832x447.png', 'F0002', 'McDonald‘s Food', 20.00,22,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483643, 0,1, 'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,96,NULL, 2147483648);
INSERT INTO "public"."product_in_order" VALUES (2147483634, 2,1, 'Under Armour', 'https://assets.academy.com/mgen/33/20088533.jpg?is=500,500', 'C0001', 'T-shirt', 10.00, 109,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483636, 0,1, 'Java SE', 'https://images-na.ssl-images-amazon.com/images/I/51S8VRHA2FL._SX357_BO1,204,203,200_.jpg', 'B0005', 'Thinking in Java', 30.00, 199,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483647, 3,1, 'Awesome', 'https://starbuckssecretmenu.net/wp-content/uploads/2017/06/Starbucks-Violet-Drink.jpg', 'D0002', 'Starbucks Violet Drink', 2.00,200,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483638, 0,1, 'Java SE', 'https://www.pearsonhighered.com/assets/bigcovers/0/1/3/2/0132778041.jpg', 'B0004', 'Effective Java', 30.00,199,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483649, 0,1, 'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,  96,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483631, 1,1, 'Family s', 'http://cdn1.thecomeback.com/wp-content/uploads/2017/05/mcdonalds_food-832x447.png', 'F0002', 'McDonald‘s Food', 20.00,  22,null ,2147483640);
INSERT INTO "public"."product_in_order" VALUES (2147483633, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00, 57, null ,2147483642);


-- ----------------------------
-- Records of product_info
-- ----------------------------
INSERT INTO "public"."product_info" VALUES ('B0003', 0, '2018-03-10 10:37:39', 'In burgers', 'https://livingonthecheap.com/lotc-cms/wp-content/uploads/2020/08/smashburger-colorado-burger-scaled-e1596562141260.jpg', 'Mexican Burger', 60.00, 0,100,  '2018-03-10 19:42:02');, 
INSERT INTO "public"."product_info" VALUES ('B0001', 0, '2018-03-10 06:44:25', 'In Breakfast Menu', 'https://th.bing.com/th/id/OIP.SWLHS3G3MFv1hSUsPsZ6MAHaEm?pid=ImgDet&rs=1', 'Chole Bhature', 30.00, 0, 100, '2018-03-10 06:44:25');
INSERT INTO "public"."product_info" VALUES ('B0004', 0, '2018-03-10 10:39:29', 'In starters', 'https://th.bing.com/th/id/R.31ea3a29a3492322d805271c2a3783ca?rik=KifJEDvah2D77A&pid=ImgRaw&r=0', 'Malai Chaap', 30.00, 0, 100, '2018-03-10 10:39:32');
INSERT INTO "public"."product_info" VALUES ('B0005', 0, '2018-03-10 10:40:35', 'In starters(Dry)', 'https://www.kurryhouzzgrill.com/wp-content/uploads/2020/06/Cheese-Chilly.jpg', 'Cheese chilly', 40.00, 0, 100, '2018-03-10 10:40:35');
INSERT INTO "public"."product_info" VALUES ('B0002', 0, '2018-03-10 10:35:43', 'Sprouts served with sauted dry fruits', 'https://th.bing.com/th/id/R.05845460dc92fd60bb36427e51a27dd6?rik=i5jfSMxmiQLUhA&riu=http%3a%2f%2flaurencariscooks.com%2f1_lcc%2fwp-content%2fuploads%2f2016%2f12%2fRaw-Brussels-Sprouts-Salad-with-Dried-Fruits-1-3.jpg&ehk=d5TCKlTTaiJeZv1ZHI2SRKf7bbm7nblBz4zLjeIIdPA%3d&risl=&pid=ImgRaw&r=0', 'Dry fruit sprout salad', 40.00, 0, 100, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0006', 0, '2018-03-10 10:35:43', 'Crispy waffle with chocolate sauce', 'https://s3-media0.fl.yelpcdn.com/bphoto/iJ7cdLOby61ze1vjgKKi6Q/o.jpg', 'Wonder Waffle', 50.00, 0,1,  '2018-03-10 10:39:32'); 
INSERT INTO "public"."product_info" VALUES ('B0007', 0, '2018-03-10 10:35:43', 'In Main Course', 'https://www.whiskaffair.com/wp-content/uploads/2020/04/Kerala-Egg-Curry-3.jpg', 'Egg curry', 30.00, 0,1,  '2018-03-10 10:39:32'); 
INSERT INTO "public"."product_info" VALUES ('B0008', 0, '2018-03-10 10:35:43', 'Fried(8 pieces)', 'https://i1.wp.com/eatwhattonight.com/wp-content/uploads/2016/11/Fried-Spring-Rolls_2.jpg', 46.00, 0, 188, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0009', 0, '2018-03-10 10:35:43', 'Dal Makhani+Shahi Paneer+Rice+1Gulab Jamun+salad+2Butter Naan', 'https://th.bing.com/th?id=OIF.KW0mm%2be4CdLxqlByZJB0OA&pid=ImgDet&rs=1', 'Veg Thali',70.00, 0, 204, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0010', 0, '2018-03-10 10:35:43', 'In Main Course', 'https://img.onmanorama.com/content/dam/mm/en/food/in-season/Ramzan/Images/hyderabadi-dum-biryani.jpg', 'Non-veg Dum Biryani', 80.00, 0,100, '2018-03-10 10:35:43');

INSERT INTO "public"."product_info" VALUES ('F0001', 1, '2018-03-10 12:15:05', 'In starters(8 pieces)', 'https://th.bing.com/th/id/OIP.hsYaSa6S9XKPBLaxeCDoKAHaFj?pid=ImgDet&rs=1', 'Veg Momos', 20.00, 0,100, '2018-03-10 12:15:10');
INSERT INTO "public"."product_info" VALUES ('F0002', 1, '2018-03-10 12:16:44', 'Sauted in mixed sauce with veggies', 'https://www.eatingonadime.com/wp-content/uploads/2020/04/greek-pasta-salad-8square.jpg','Italian Pasta' 40.00, 0, 220, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0003', 1, '2018-03-10 12:16:44', 'In starters', 'https://th.bing.com/th/id/OIP.6x-EQdmYh2ivib3T-CkciAHaE7?pid=ImgDet&rs=1', 'Veg Hakka Noodles', 30.00, 0, 100, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0004', 1, '2018-03-10 12:16:44', 'Fries with combination of 7 cheese', 'https://delishar.com/wp-content/uploads/2016/03/Cheese-Fries.jpg', 'Cheesy Fries', 40.00, 0, 290, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0005', 1, '2018-03-10 12:16:44', 'Rice with veggies and soya chunks', 'https://th.bing.com/th/id/OIF.BE3ONt8TcLCNqYB9nLZUOQ?pid=ImgDet&rs=1', 'Veg Pulao', 45.00, 0, 209, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0006', 1, '2018-03-10 12:16:44', 'Topped with spring onions(Gravy)', 'https://i0.wp.com/angsarap.net/wp-content/uploads/2013/01/vegetable-manchurian.jpg', 'Veg Manchurian', 40.00, 0, 189, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0007', 1, '2018-03-10 12:16:44', 'Nothing says Italian like tomato,red paprika,olives and Italian dip', 'https://jamundi.jackyspizza.com/wp-content/uploads/2022/02/pizza-potochino_900x1100-768x768.jpg', 'Italiano Pizza', 100.00, 0, 193, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0008', 1, '2018-03-10 12:16:44', 'In Main Course', 'https://www.cookwithmanali.com/wp-content/uploads/2015/01/Restaurant-Style-Dal-Makhani-Recipe.jpg', 'Dal Makhani with Naan', 50.00, 0, 100, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0009', 1, '2018-03-10 12:16:44', 'In Main Course', 'https://th.bing.com/th/id/R.1305e083aad3c867c20d74ed263b704e?rik=hGZT%2fLJX6bBVyg&pid=ImgRaw&r=0', 'Malai Kofta', 30.00, 0, 100, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0010', 1, '2018-03-10 12:16:44', 'Serves 2', 'https://thumbs.dreamstime.com/b/kadhi-chawal-yogurt-curry-rice-indian-dish-155652315.jpg', 'Kadhi Chawal', 30.00, 0, 295, '2018-03-10 12:16:44');

INSERT INTO "public"."product_info" VALUES ('C0003', 2, '2018-03-10 12:12:46', 'In starters', 'https://th.bing.com/th/id/OIP.5-OT2zsD4HelAnOIIMykiAHaFj?pid=ImgDet&rs=1', 'Chilly chicken', 50.00, 0,100, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0001', 2, '2018-03-10 12:09:41', 'Murg malai tikka(6 pieces),murg tandoori tikka(4 pieces),tandoori chicken(4 pieces)', 'https://images.indulgexpress.com/uploads/user/ckeditor_images/article/2019/9/19/Tandoori_non_veg_platter.jpg', 'Non-Veg Platter', 80.00, 0, 110, '2018-03-10 12:09:41');
INSERT INTO "public"."product_info" VALUES ('C0002', 2, '2018-03-10 12:11:51', 'Soup recipe with onion,tomatoes,spices & herbs', 'https://d4t7t8y8xqo0t.cloudfront.net/resized/750X436/restaurant%2F500419%2F0.jpg', 'Non-veg Shorba', 35.00, 0, 190, '2018-03-10 12:11:51');
INSERT INTO "public"."product_info" VALUES ('C0004', 2, '2018-03-10 12:12:46', 'A chinese cuisine with meat,vegetables and noodles', 'https://th.bing.com/th?id=OIF.gy%2fzg3E66mA5J7wzsjTNrA&pid=ImgDet&rs=1', 'Laghman', 50.00, 0, 250, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0005', 2, '2018-03-10 12:12:46', 'Serves 2', 'https://4funpedia.com/wp-content/uploads/2022/01/recipe-yummy-fish-curry_61ebf4f6c5c24.jpeg', 'Malabar fish curry', 70.00, 0, 207, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0006', 2, '2018-03-10 12:12:46', 'Dumplings filled with meat and marinated in yogurt and spices', 'https://xyuandbeyond.com/wp-content/uploads/2019/01/Manti-by-Lachlan-Hardy-e1559035915369.jpg', 'Manti Turkish Dumplings', 80.00, 0, 239, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0007', 2, '2018-03-10 12:12:46', 'Pork pepperoni with Extra cheese ', 'https://th.bing.com/th/id/OIF.YgBQBif7wkPGvhjhobBsEA?pid=ImgDet&rs=1', 'Pepperoni Pizza', 120.00, 0, 257, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0008', 2, '2018-03-10 12:12:46', 'Serves 2(Gravy)', 'https://th.bing.com/th/id/OIF.R43T9DsSGaLx50TCSH2gyg?pid=ImgDet&rs=1', 'Rada chicken', 85.00, 0, 288, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0009', 2, '2018-03-10 12:12:46', 'Serves 2', 'https://th.bing.com/th/id/OIP.Y9UkEaNbIRNzMqsBf_gIegHaEK?pid=ImgDet&rs=1', 'Butter chicken with Garlic naan', 70.00, 0, 100, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0010', 2, '2018-03-10 12:12:46', 'Served with the goodness of rich spices,meat and fried eggs', 'https://briyani.com/wp-content/uploads/2022/03/20220303015354_menu_photo.jpg?is-pending-load=1', 'Malabar fish biryani', 90.00, 0, 210, '2018-03-10 12:12:46');

INSERT INTO "public"."product_info" VALUES ('D0001', 3, '2018-03-10 06:51:03', 'Topped with ice-cream and oreo chuncks', 'https://th.bing.com/th/id/R.9061835916f0ec4bfb671dd75d896eaa?rik=FbhBhY5GhIgvbA&pid=ImgRaw&r=0', 'Oreo Shake', 40.00, 0,100, '2018-03-10 12:04:13');
INSERT INTO "public"."product_info" VALUES ('D0002', 3, '2018-03-10 12:08:17', 'In premium beverages', 'https://d2n7tchuu1wmsv.cloudfront.net/uploads/11441/products/1589369345_brownieshake11.jpg', 'Chocolate Brownie Shake', 40.00, 0,100, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0003', 3, '2018-03-10 12:08:17', 'Topped with crushed berries and cream', 'https://starbuckssecretmenu.net/wp-content/uploads/2017/06/Starbucks-Violet-Drink.jpg', 'Starbucks Blueberry Shake', 40.00, 0, 199, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0004', 3, '2018-03-10 12:08:17', 'In carbonated drinks', 'https://th.bing.com/th/id/OIP.vWRjULFQy2q3XmSzKtYS1AHaE6?pid=ImgDet&rs=1', 'Coca-cola', 25.00, 0, 209, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0005', 3, '2018-03-10 12:08:17', 'In carbonated drinks', 'https://th.bing.com/th/id/OIP.OVZb5I34DR3WtHV3Pe3RJgHaHa?pid=ImgDet&rs=1', 'Limca', 25.00, 0, 201, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0006', 3, '2018-03-10 12:08:17', 'Served hot(4 pieces)', 'https://i0.wp.com/www.milkandcardamom.com/wp-content/uploads/2016/11/Gulab-Jamun-6.jpg?w=1460', 'Gulab Jamun', 40.00, 0, 200, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0007', 3, '2018-03-10 12:08:17', '2 pieces', 'https://th.bing.com/th/id/OIP.UPHy6Jz44QYsRctdS1-ynQHaHu?pid=ImgDet&rs=1', 'Rasmalai',40.00, 0, 197, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0008', 3, '2018-03-10 12:08:17', 'In cakes and pastries(2 pieces)', 'https://th.bing.com/th/id/OIF.vi1USBnA3HQBGzoRrL4dtA?pid=ImgDet&rs=1', 'Chocolate mousse pastry', 30.00, 0, 248, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0009', 3, '2018-03-10 12:08:17', 'In cakes and pastries(2 pieces)', 'https://th.bing.com/th/id/OIF.wnvU6eGu7ggzAmm6s5xgsw?pid=ImgDet&rs=1', 'White forest pastry', 30.00, 0, 250, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0010', 3, '2018-03-10 12:08:17', 'In cakes and pastries(500 gm)', 'https://i0.wp.com/maverickbaking.com/wp-content/uploads/2016/07/DSC02899.jpg', 'Red velvet cake', 150.00, 0, 290, '2018-03-10 12:08:17');

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO "public"."users" VALUES (2147483641, 't', 'New bus Station, Kanpur, Uttar Pradesh', 'customer1@email.com', 'customer1', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '1234567890', 'ROLE_CUSTOMER');
INSERT INTO "public"."users" VALUES (2147483642, 't', 'Lucknow HQ (UP)', 'lucknow.hq@vatiwala.com', 'Lucknow HQ', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '9998887770', 'ROLE_MANAGER');
INSERT INTO "public"."users" VALUES (2147483643, 't', 'Kanpur HUB (UP) ', 'kanpur.hub@vatiwala.com', 'Kanpur HUB', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '1231231231', 'ROLE_EMPLOYEE');
INSERT INTO "public"."users" VALUES (2147483645, 't', 'Fazalganj, Kanpur, UP', 'customer2@email.com', 'customer2', '$2a$10$0oho5eUbDqKrLH026A2YXuCGnpq07xJpuG/Qu.PYb1VCvi2VMXWNi', '9876543210', 'ROLE_CUSTOMER');

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO "public"."cart" VALUES (2147483641);
INSERT INTO "public"."cart" VALUES (2147483642);
INSERT INTO "public"."cart" VALUES (2147483643);
INSERT INTO "public"."cart" VALUES (2147483645);


